# Thesis benchmark figures

Source: C:\Users\nevena.mijailovic\Desktop\folder\dotnet\projectdotnet\results\thesis_final_01\analysis\protocol_aggregates.csv

Each figure uses the mean of five repetitions. Error bars show one standard deviation where the analyzer provides it. Protocol colors and markers are consistent across all figures:

- WebSocket: blue circle
- Server-Sent Events: green square
- Long Polling: orange triangle

Scenario filters:

- Client sweep: payload 1,024 B and generation rate 500 messages/s.
- Message-rate sweep: 50 clients and payload 1,024 B.
- Payload sweep: 10 clients and generation rate 100 messages/s.

Latency figures use a logarithmic y-axis so the low WebSocket/SSE values and Long Polling saturation remain visible in the same plot. Client and payload sweeps use a logarithmic x-axis because their selected values span several orders of magnitude.